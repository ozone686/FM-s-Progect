
===========
Demos queue
===========

\dmq_add [ TYPE: COMMAND - PARAMETERS : file or directory] - adds a demo or a directory contents to the demos queue.
\dmq_clear [ TYPE: COMMAND ] - Resets the demo queue.
\dmq_play [ TYPE: COMMAND ] - Starts the demos queue playback.
\dmq_stop [ TYPE: COMMAND ] - Stops and cancels the demos queue playback.