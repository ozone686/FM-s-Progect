======
Thanks
======

The Defrag team would like to extend is gratitude to all the people who have helped make defrag better and better with each new release

1. Ideas
2. Testers
3. IRC Channels
4. Misc.

Special thanks go to Id Software for providing many great games, and catering to the needs of the modding community.  Thanks also goes to arQon and the Promode team for having kindly provided CPM Physics sources, and to Camping Gaz for providing very innovative and imaginative ideas.

--------
1. Ideas
-------- 
Camping Gaz - for his great ideas: freecam of demos, keypress indication, savepos, and the rudimentary idea of the accelmeter.
Space and Cheez - for help and ideas relating to the Ghost features.
Costanza and CeTuS - for help and ideas relating to the Accelmeter.
Space and B3nt - for help and feedback relating to the various DemoCamming features.
Space - help, ideas, and assistance with Replay Scripting, Democams, and a whole bunch of other stuff.
Zargoth - ghosts Live Ammo idea.
Michael Flatley - VelocityPads
B3nt - Blackscreening
Firestarter - for providing his swinging style grappling hook physics code (from corkscrew mod)
devilman6 - PIP multiplayer spectating idea

----------
2. Testers
----------
CeTuS, Sektor, Uni, MelGibbsEm, B3nt, Michael Flatley, m1tsu, edisdead, Cheez, Costanza
All the Defrag beta testers.

---------------
3. IRC Channels
---------------
#defrag on quakenet - thanks to the numerous players, mappers, trickers, etc. on #defrag... you know who you are :)
#defragmap on quakenet
#defrag-france on quakenet
#trickingq3 on enter the game (etg)
#teamix on enter the game (etg)

--------
4. Misc.
--------
www.overdrivepc.com (opc)
forum members at opc

Teams:	iT, ix, pj, 14k, afz, ltu, austrix, team blue

Lastly, appologies to anyone we inadvertantly left of the list.  Thanks to you, who ever you are :P :)
