* history 1.71 *

- Fixed any items-related problem from 1.7
- Fast Caps: Players always use first-spawn spots
- Tricks Mode: Added "no weapon" mo 
- Tricks Mode: Fixed timer-assigned bfg overriding item pickup rules
- Authentication failures no longer kill server
