============
Installation
============

1. Information

==============
1. Information
==============

1. Installation: If you unzip the Defrag install zip without using the folders option, you will end up putting all the files into the main defrag folder. This is wrong. You'll end up with greenskies, replay scripts won't work, etc. Unzip with folders option. You should end up with a single "defrag" folder under your quake3 folder.

quake3
..............defrag
....................docs
....................misc
.........................[...misc subfolders...]
....................system
.........................[...system subfolders...]
