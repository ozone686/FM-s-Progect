
=================
Automated Scripts
=================

/df_script_onRespawn [0-1] (default: 0)
	Executes respawn.cfg each time player respawns.	Basically used for alternative demos recording scripts.
	
/df_script_onMapLoad [0-1] (default: 0)
	Executes [mapname].cfg after a map is loaded.
	Basically used for specific map settings (sv_fps, com_maxFps, ...) and user defined timers.
